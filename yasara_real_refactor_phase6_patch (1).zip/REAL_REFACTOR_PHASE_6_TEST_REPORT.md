Adds 4 tests.
