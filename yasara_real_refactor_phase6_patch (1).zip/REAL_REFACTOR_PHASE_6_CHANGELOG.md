Real Refactor Phase 6 added safe cleanup and archive plan.
