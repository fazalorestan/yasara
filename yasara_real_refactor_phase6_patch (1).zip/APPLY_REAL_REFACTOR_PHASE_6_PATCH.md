# Apply Real Refactor Phase 6 Patch

Extract into:

`D:\yasara\yasara`

Then run:

```cmd
cd /d D:\yasara\yasara\backend
python scripts\apply_real_refactor_phase6_router_patch.py
set PYTHONPATH=%CD%
python -m pytest tests
```

Adds 4 tests.
