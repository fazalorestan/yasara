from fastapi import APIRouter
from app.core_refactor_v1.archive_policy import ArchivePolicyBuilderV1
from app.core_refactor_v1.cleanup_archive_gate import CleanupArchiveGateBuilderV1
from app.core_refactor_v1.refactor_phase6_summary import RefactorPhase6SummaryBuilderV1
from app.core_refactor_v1.safe_cleanup_manifest import SafeCleanupManifestBuilderV1

router = APIRouter(prefix="/core-refactor-phase6-v1", tags=["core-refactor-phase6-v1"])

@router.get("/archive-policy")
async def archive_policy():
    return ArchivePolicyBuilderV1().build()

@router.get("/cleanup-manifest")
async def cleanup_manifest():
    return SafeCleanupManifestBuilderV1().build()

@router.get("/gate")
async def gate():
    return CleanupArchiveGateBuilderV1().build()

@router.get("/summary")
async def summary():
    return RefactorPhase6SummaryBuilderV1().build()
