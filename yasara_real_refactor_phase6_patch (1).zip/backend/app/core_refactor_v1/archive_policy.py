from pydantic import BaseModel, Field

class ArchivePolicyItemV1(BaseModel):
    pattern: str
    destination: str
    action: str = "archive"
    safe: bool = True

class ArchivePolicyV1(BaseModel):
    items: list[ArchivePolicyItemV1] = Field(default_factory=list)

class ArchivePolicyBuilderV1:
    def build(self) -> ArchivePolicyV1:
        return ArchivePolicyV1(items=[
            ArchivePolicyItemV1(pattern="REAL_REFACTOR_PHASE_*.md", destination="docs/archive/refactor"),
            ArchivePolicyItemV1(pattern="FINAL_*_PHASE*.md", destination="docs/archive/finalization"),
            ArchivePolicyItemV1(pattern="APPLY_*_PATCH.md", destination="docs/archive/patch_guides"),
            ArchivePolicyItemV1(pattern="*_CHANGELOG.md", destination="docs/archive/changelogs"),
            ArchivePolicyItemV1(pattern="*_TEST_REPORT.md", destination="docs/archive/test_reports"),
            ArchivePolicyItemV1(pattern="*_SECURITY_REVIEW.md", destination="docs/archive/security_reviews"),
        ])
