from pydantic import BaseModel, Field
from app.core_refactor_v1.archive_policy import ArchivePolicyBuilderV1
from app.core_refactor_v1.safe_cleanup_manifest import SafeCleanupManifestBuilderV1

class CleanupArchiveGateV1(BaseModel):
    ready: bool
    checks: list[str] = Field(default_factory=list)
    note: str = "Archive and cleanup policies are descriptive; cleanup scripts remain source-safe."

class CleanupArchiveGateBuilderV1:
    def build(self) -> CleanupArchiveGateV1:
        archive = ArchivePolicyBuilderV1().build()
        cleanup = SafeCleanupManifestBuilderV1().build()
        return CleanupArchiveGateV1(
            ready=bool(archive.items and cleanup.items) and all(i.safe for i in archive.items) and all(i.source_safe for i in cleanup.items),
            checks=["archive_policy", "safe_cleanup_manifest"],
        )
