from pydantic import BaseModel, Field
from app.core_refactor_v1.cleanup_archive_gate import CleanupArchiveGateBuilderV1

class RefactorPhase6SummaryV1(BaseModel):
    ready: bool
    phase: str = "real_refactor_phase_6_safe_cleanup_archive"
    checks: list[str] = Field(default_factory=list)
    next_phase: str = "final_refactor_completion"

class RefactorPhase6SummaryBuilderV1:
    def build(self) -> RefactorPhase6SummaryV1:
        gate = CleanupArchiveGateBuilderV1().build()
        return RefactorPhase6SummaryV1(ready=gate.ready, checks=gate.checks)
