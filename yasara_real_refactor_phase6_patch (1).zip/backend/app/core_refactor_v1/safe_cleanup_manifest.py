from pydantic import BaseModel, Field

class SafeCleanupItemV1(BaseModel):
    pattern: str
    action: str = "delete"
    source_safe: bool = True
    reason: str = ""

class SafeCleanupManifestV1(BaseModel):
    items: list[SafeCleanupItemV1] = Field(default_factory=list)

class SafeCleanupManifestBuilderV1:
    def build(self) -> SafeCleanupManifestV1:
        return SafeCleanupManifestV1(items=[
            SafeCleanupItemV1(pattern="__pycache__", reason="Python cache"),
            SafeCleanupItemV1(pattern=".pytest_cache", reason="Pytest cache"),
            SafeCleanupItemV1(pattern=".ruff_cache", reason="Ruff cache"),
            SafeCleanupItemV1(pattern=".mypy_cache", reason="Mypy cache"),
            SafeCleanupItemV1(pattern="*.pyc", reason="Compiled Python cache"),
            SafeCleanupItemV1(pattern="*.log", reason="Runtime logs"),
            SafeCleanupItemV1(pattern="*.tmp", reason="Temporary files"),
        ])
