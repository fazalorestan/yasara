@echo off
setlocal
echo =========================================
echo YaSara Refactor Safe Archive/Cleanup Plan
echo =========================================
echo.
echo This script is informational and source-safe.
echo It does not move or delete source files automatically.
echo.
echo Recommended:
echo 1. Run full tests
echo 2. Archive phase markdown files into docs/archive
echo 3. Run safe cleanup for caches only
echo 4. Create final package
echo.
pause
