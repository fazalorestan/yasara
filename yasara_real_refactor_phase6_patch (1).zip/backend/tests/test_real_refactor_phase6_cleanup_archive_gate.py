from app.core_refactor_v1.cleanup_archive_gate import CleanupArchiveGateBuilderV1

def test_cleanup_archive_gate():
    gate = CleanupArchiveGateBuilderV1().build()
    assert gate.ready is True
