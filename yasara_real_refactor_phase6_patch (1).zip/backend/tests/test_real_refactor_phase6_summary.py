from app.core_refactor_v1.refactor_phase6_summary import RefactorPhase6SummaryBuilderV1

def test_refactor_phase6_summary():
    summary = RefactorPhase6SummaryBuilderV1().build()
    assert summary.ready is True
    assert summary.next_phase == "final_refactor_completion"
