from app.core_refactor_v1.safe_cleanup_manifest import SafeCleanupManifestBuilderV1

def test_safe_cleanup_manifest():
    manifest = SafeCleanupManifestBuilderV1().build()
    assert any(i.pattern == "__pycache__" for i in manifest.items)
    assert all(i.source_safe for i in manifest.items)
