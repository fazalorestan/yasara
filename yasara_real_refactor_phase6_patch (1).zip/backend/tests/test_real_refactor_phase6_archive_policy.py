from app.core_refactor_v1.archive_policy import ArchivePolicyBuilderV1

def test_archive_policy():
    policy = ArchivePolicyBuilderV1().build()
    assert any(i.destination == "docs/archive/refactor" for i in policy.items)
    assert all(i.safe for i in policy.items)
