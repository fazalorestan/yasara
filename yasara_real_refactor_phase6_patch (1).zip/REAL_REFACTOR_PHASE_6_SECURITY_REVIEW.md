Source-safe archive/cleanup planning only.
