"""YaSara consolidation phase A."""
