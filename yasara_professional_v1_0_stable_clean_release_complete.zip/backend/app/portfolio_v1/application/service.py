from app.portfolio_v1.domain.models import PortfolioSnapshot
from app.portfolio_v1.engine.portfolio_engine import PortfolioIntelligenceEngineV1

class PortfolioIntelligenceServiceV1:
    def __init__(self):
        self.engine = PortfolioIntelligenceEngineV1()

    async def analyze(self, snapshot: PortfolioSnapshot, price_returns: dict[str, list[float]] | None = None, targets: dict[str, float] | None = None):
        return self.engine.analyze(snapshot, price_returns, targets)

portfolio_intelligence_service_v1 = PortfolioIntelligenceServiceV1()
