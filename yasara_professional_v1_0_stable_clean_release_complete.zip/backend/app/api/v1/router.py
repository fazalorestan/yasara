from app.api.v1.routes import final_export_scripts_v1, project_end_v1, archive_handoff_v1, production_freeze_v1, final_operations_v1, final_delivery_pack_v1, final_closeout_v1, final_package_v1, final_export_v1, final_docs_qa_v1, final_release_engineering_v1, final_integration_v1, stable_release_v1, final_release_v1, rc1_hardening_v1, rc1_v1, enterprise_v1, production_packaging_v1, consolidation_phase_b_v1, consolidation_v1, release_pro_v1, cloud_v1, desktop_ui_v1, multi_exchange_extras_v1, multi_exchange_v1, version_v1, release_v1, production_ai_v1, mobile_v1, dashboard_v1, strategy_builder_v1, account_sync_v1, exchange_private_v1, secrets_v1, notifications_v1, execution_v1, paper_trading_v1, portfolio_v1, backtest_v1, risk_v1, decision_v1, intelligence_v1, market_data
from fastapi import APIRouter

from app.api.v1.health import router as health_router

api_router = APIRouter()
api_router.include_router(health_router, tags=["health"])

api_router.include_router(market_data.router)

api_router.include_router(intelligence_v1.router)

api_router.include_router(decision_v1.router)

api_router.include_router(risk_v1.router)

api_router.include_router(backtest_v1.router)

api_router.include_router(portfolio_v1.router)

api_router.include_router(paper_trading_v1.router)

api_router.include_router(execution_v1.router)

api_router.include_router(notifications_v1.router)

api_router.include_router(secrets_v1.router)

api_router.include_router(exchange_private_v1.router)

api_router.include_router(account_sync_v1.router)

api_router.include_router(strategy_builder_v1.router)

api_router.include_router(dashboard_v1.router)

api_router.include_router(mobile_v1.router)

api_router.include_router(production_ai_v1.router)

api_router.include_router(release_v1.router)

api_router.include_router(version_v1.router)

api_router.include_router(multi_exchange_v1.router)

api_router.include_router(multi_exchange_extras_v1.router)

api_router.include_router(desktop_ui_v1.router)

api_router.include_router(cloud_v1.router)

api_router.include_router(release_pro_v1.router)

api_router.include_router(consolidation_v1.router)

api_router.include_router(consolidation_phase_b_v1.router)

api_router.include_router(production_packaging_v1.router)

api_router.include_router(enterprise_v1.router)

api_router.include_router(rc1_v1.router)

api_router.include_router(rc1_hardening_v1.router)

api_router.include_router(final_release_v1.router)

api_router.include_router(stable_release_v1.router)

api_router.include_router(final_integration_v1.router)

api_router.include_router(final_release_engineering_v1.router)

api_router.include_router(final_docs_qa_v1.router)

api_router.include_router(final_export_v1.router)

api_router.include_router(final_package_v1.router)

api_router.include_router(final_closeout_v1.router)

api_router.include_router(final_delivery_pack_v1.router)

api_router.include_router(final_operations_v1.router)

api_router.include_router(production_freeze_v1.router)

api_router.include_router(archive_handoff_v1.router)

api_router.include_router(project_end_v1.router)

api_router.include_router(final_export_scripts_v1.router)
